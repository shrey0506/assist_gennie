from langgraph.graph import StateGraph
from agentic_ai_app.agents import pdf_agent, confluence_agent, web_agent, llm_agent, codegen_agent

async def run_graph(query, history, chat_id):
    graph = StateGraph()
    
    graph.add_node("pdf", pdf_agent.check_pdf)
    graph.add_node("confluence", confluence_agent.check_confluence)
    graph.add_node("web", web_agent.check_web)
    graph.add_node("llm", llm_agent.respond)
    graph.add_node("codegen", codegen_agent.generate_code)

    graph.set_entry_point("pdf")
    graph.add_edge("pdf", "confluence")
    graph.add_edge("confluence", "web")
    graph.add_edge("web", "llm")
    graph.add_edge("llm", "codegen")
    graph.set_exit_point("codegen")

    return await graph.run(query=query, history=history, chat_id=chat_id)