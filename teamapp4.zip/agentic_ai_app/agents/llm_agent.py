from agentic_ai_app.utils.vertexai import call_vertex_llm

async def respond(query, history, chat_id):
    return {"source": "llm", "answer": call_vertex_llm(query)}