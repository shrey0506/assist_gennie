async def check_web(query, history, chat_id):
    # Logic to query DuckDuckGo or other web data
    # Placeholder logic
    return {"source": "web", "answer": "Web search result"}