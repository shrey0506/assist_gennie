async def generate_code(query, history, chat_id):
    return {"source": "codegen", "code": f"# Code generated for: {query}"}