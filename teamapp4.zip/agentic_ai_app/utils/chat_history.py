history_store = {}

def get_history(chat_id):
    return history_store.get(chat_id, [])

def update_history(chat_id, query, response):
    if chat_id not in history_store:
        history_store[chat_id] = []
    history_store[chat_id].append({"query": query, "response": response})