def fetch_pdf_data(query):
    # Placeholder function for fetching from AlloyDB
    return "PDF data"

def fetch_confluence_data(query):
    return "Confluence data"