def get_embedding(text):
    # Placeholder for embedding function
    return [0.1] * 768