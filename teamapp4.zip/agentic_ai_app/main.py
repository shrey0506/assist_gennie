from fastapi import FastAPI, Request
from agentic_ai_app.graph import run_graph
from agentic_ai_app.utils.chat_history import get_history, update_history

app = FastAPI()

@app.post("/chat")
async def chat(request: Request):
    body = await request.json()
    user_query = body.get("query")
    chat_id = body.get("chat_id")
    history = get_history(chat_id)
    response = await run_graph(user_query, history, chat_id)
    update_history(chat_id, user_query, response)
    return {"response": response}